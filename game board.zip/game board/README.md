SOLO PROJECT

This is my basketball scoreboard that I was able to design.
After following the module 3 with Scimba.com, I was able to do this as my first javascript solo project.
