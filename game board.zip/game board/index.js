let scoreHome = document.getElementById("score-home")
let scoreGuest = document.getElementById("score-guest")
document.getElementById("score-home").textContent = 0
document.getElementById("score-guest").textContent = 0
let num1 = 0
function addone()  {
    num1 += 1
    scoreHome.textContent = num1   
}
function addtwo(){
    num1 += 2
    scoreHome.textContent = num1 
}
function addthree(){
    num1 += 3
    scoreHome.textContent = num1 
}
let num2 = 0
function addoneguest(){
    num2 += 1
    scoreGuest.textContent = num2 
}
function addtwoguest(){
    num2 += 2
    scoreGuest.textContent = num2 
}
function addthreeguest(){
    num2 += 3
    scoreGuest.textContent = num2 
}